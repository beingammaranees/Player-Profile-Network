import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class DatabaseImplementation {
    Scanner scanner = null;
    Connection connection = null;

    public DatabaseImplementation(Connection conn) {
        // initializing with paramterized constructors will help much better than to individually pass connection parameters to each method
        this.connection = conn;
        scanner = new Scanner((System.in));
    }

    void CreateNewTableOnSignUp(String tableName) {
        try {
            Statement statement = this.connection.createStatement();
            statement.execute("CREATE TABLE IF NOT EXISTS " + tableName + " (\n" + "	id integer NOT NULL,\n" + "	yourgames text ,\n" + "	purchasehistory text\n" + ");");
            MessageConfirmation("A new table with name " + tableName + " has been created");
        } catch (Exception e) {
            System.out.println("System is throwing an exception " + e.getMessage());
        }
        ;
    }

    int GetLastIdNumberFromAllUsers(String table) {

        // just to return what's the latest id to help update the table entities
        try {
            Statement st = this.connection.createStatement();
            ResultSet rs = st.executeQuery("Select * from " + table);
            int idCount = 0;
            while (rs.next()) {
                idCount++;
            }
            return idCount;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return 1;
    }

    void AddNewUserInformation(String username, String password) {
        int latestId = GetLastIdNumberFromAllUsers("allusers");
        String stringId = String.valueOf(latestId + 1);
        String insertQuery = "INSERT INTO allusers VALUES(?,?,?)";
        try {
            PreparedStatement ps = this.connection.prepareStatement(insertQuery);// you can also get key iD by using further arguments
            ps.setString(1, stringId);
            ps.setString(2, username);
            ps.setString(3, password);
            ps.executeUpdate();
            System.out.println("User has been added with formatted ID number i.e " + String.valueOf(latestId + 1));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    void Signup(String username, String password) {
        // first we will have to signup and create table for that newly signed-up user
//        System.out.print("Enter your username: ");
//        String username = scanner.nextLine();
//        System.out.print("Set your password: ");
//        String password1 = scanner.nextLine();
//        System.out.print("Confirm your password: ");
//        String password2 = scanner.nextLine();


        CreateNewTableOnSignUp(username);
        AddNewUserInformation(username, password);
        // also make a another table for storing user information, like their passwords and usernames


    }

    void MessageConfirmation(String msg) {
        System.out.println(msg);
    }

    void LoginUser() {
        // user will log-in through username and the password
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String pass = scanner.nextLine();
        if (AuthenticateUser(username, pass)) {
            System.out.println("User found");
        } else {
            System.out.println("User not found");
        }

    }

    boolean AuthenticateUser(String username, String password) {
        boolean value = false;
        try {
            Statement st = this.connection.createStatement();
            ResultSet rs = st.executeQuery("select * from allusers");

            while (rs.next()) {
                if (username.equals(rs.getString("username")) && password.equals(rs.getString("password"))) {
                    // it means we have found both the username and the password
                    value = true;
                    break;

                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return value;
    }

    boolean AddPurchasedGames(String gameName, int purchasedAmount, String username) {
        // remember this purchased amount is for transaction/purchase history
        int latestId = GetLastIdNumberFromAllUsers(username);  // now we've got the latest id
        System.out.println("Latest id is " + latestId);

        String query = "insert into " + username + " values(?,?,?)";
        System.out.println("Query is " + query);
        try {
            PreparedStatement ps = this.connection.prepareStatement(query);
            ps.setString(1, String.valueOf(latestId + 1));
            ps.setString(2, gameName);
            ps.setString(3, String.valueOf(purchasedAmount));
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;

    }

    void DisplayGamesAvailableOnStore() {
        // games that will be available on store are available for the user to see them
        // he will get the game names and can add to cart or favs
        // we have games(table) -> columns -> normalgames, discountedgames, freegames
        try {
            Statement st = this.connection.createStatement();
            ResultSet rs = st.executeQuery("select * from games");

            while (rs.next()) {
                System.out.println(rs.getString("normalgames") + ", " + rs.getString("discountedgames") + ", " + rs.getString("freegames"));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

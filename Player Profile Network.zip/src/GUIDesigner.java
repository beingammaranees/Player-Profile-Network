import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.xml.transform.Result;
import java.sql.*;
import java.util.ArrayList;
/*
 * Created by JFormDesigner on Tue Jan 24 18:00:54 PKT 2023
 */


/**
 * @author itsAs
 */
public class GUIDesigner extends JPanel {

    DatabaseImplementation databaseObject = null;
    Connection connection = null;
    int currentPriceFlag = 0;
    String gameSelected = "";
    String username = "";

    public GUIDesigner(DatabaseImplementation databaseObject, Connection connection) {

        initComponents();
        SetDefaultVisibility();
        this.databaseObject = databaseObject;
        this.connection = connection;
    }

    void SetDefaultVisibility() {
        // when the program starts, everything is set to their default visible state

    }

    void MyGamesDataGetter() {
        try {
            Statement statement = this.connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select * from " + this.username);
            ArrayList<String> gamesList = new ArrayList<>();
//            gamesList.clear();
            ArrayList<String> purchaseList = new ArrayList<>();
            while (resultSet.next()) {
                gamesList.add(resultSet.getString("yourgames"));
                purchaseList.add("$"+resultSet.getString("purchasehistory"));
            }
            myGamesList.setListData(gamesList.toArray());
            transactionList.setListData(purchaseList.toArray());
            System.out.println("Now your games list is \n");
            for (int i = 0; i < gamesList.size(); i++) {
                System.out.println(gamesList.get(i) + "\n");
            }
//            myPurchaseHistoryList.setListData(purchaseList.toArray());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void OnClickLogin(ActionEvent e) {
        String username = loginUsernameTextField.getText();
        String password = loginPasswordTextField.getText();
        if (databaseObject.AuthenticateUser(username, password)) {
            JOptionPane.showMessageDialog(this, "Login Successful");
            this.username = username;
            this.setVisible(false);
            frame1.setVisible(true);
            loginUsernameTextField.setText("");
            loginPasswordTextField.setText("");

            MyGamesDataGetter();  // this is only to retrieve data for the game records

            // when the login is successful, hide this and the show the new one
            // make a new query and show the full table of that user created to show his all types of games

            ArrayList<String> normalGames = new ArrayList<>();
            ArrayList<String> discountedGames = new ArrayList<>();
            ArrayList<String> freeGames = new ArrayList<>();

            try {
                Statement st = this.connection.createStatement();
                ResultSet rs = st.executeQuery("select * from games");

                while (rs.next()) {
//                    System.out.println(rs.getString("normalgames") + ", " + rs.getString("discountedgames") + ", " + rs.getString("freegames"));
                    normalGames.add(rs.getString("normalgames"));
                    discountedGames.add(rs.getString("discountedgames"));
                    freeGames.add(rs.getString("freegames"));
                }

                normalGamesList.setListData(normalGames.toArray());
                discounedGamesList.setListData(discountedGames.toArray());
                freeGamesList.setListData(freeGames.toArray());
                System.out.println("Getting the name of the variable " + freeGamesList.getName());

            } catch (Exception exception) {
                System.out.println(exception.getMessage());
            }


        } else {
            JOptionPane.showMessageDialog(this, "User not found");
        }
    }

    private void normalGamesListValueChanged(ListSelectionEvent e) {
        // when some values from this list are selected, mention a flag for 500$ price setter
        discounedGamesList.clearSelection();
        freeGamesList.clearSelection();
        currentPriceFlag = 500;
        gameSelected = normalGamesList.getSelectedValue().toString();
    }

    private void discounedGamesListValueChanged(ListSelectionEvent e) {
        // TODO add your code here
        normalGamesList.clearSelection();
        freeGamesList.clearSelection();
        currentPriceFlag = 300;
        gameSelected = discounedGamesList.getSelectedValue().toString();
    }

    private void freeGamesListValueChanged(ListSelectionEvent e) {
        // TODO add your code here
        normalGamesList.clearSelection();
        discounedGamesList.clearSelection();
        currentPriceFlag = 0;
        gameSelected = freeGamesList.getSelectedValue().toString();
    }

    private void button1(ActionEvent e) {
        // TODO add your code here
    }

    private void OnClickPurchase(ActionEvent e) {
        if (gameSelected.equals("")) {
            // if none of the game is selected
            JOptionPane.showMessageDialog(this, "You need to select atleast one game, " + this.username);
        } else {

            String customMessage = "You're about to purchase '" + gameSelected + "' WORTH $" + String.valueOf(currentPriceFlag) + "!";
//            int dialogueButtonType=JOptionPane.YES_NO_OPTION;
            int dialogueResult = JOptionPane.showConfirmDialog(this, customMessage);
            if (dialogueResult == JOptionPane.YES_OPTION) {


                JOptionPane.showMessageDialog(this, "Alright confirmed");
                // now when the purchasing is confirmed, add this game to user's database with columns heading purchased games
                if (databaseObject.AddPurchasedGames(gameSelected, currentPriceFlag, this.username)) {
                    JOptionPane.showMessageDialog(this, "Game purchased successfully");
                    myGamesList.clearSelection();
                    MyGamesDataGetter();   // so everytime we purchase something, our list is updated
                } else {
                    JOptionPane.showMessageDialog(this, "Purchasing error");
                }

            }
        }
    }


    private void OnClickSignup(ActionEvent e) {
        // TODO add your code here
        String username = signUpUsernameTextField.getText();
        String password = signUpPasswordTextField.getText();
        String confirmedPassword = signUpConfirmPasswordTextField2.getText();

        if (username.equals("")) {
            JOptionPane.showMessageDialog(this, "Username field is empty");
        } else if (!password.equals(confirmedPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords mismatch");
        } else {
            // when everything's ok
            databaseObject.Signup(username, password);
            // set all entries of signup to false
            signUpUsernameTextField.setText("");
            signUpConfirmPasswordTextField2.setText("");
            signUpPasswordTextField.setText("");
            JOptionPane.showMessageDialog(this, "You have registered yourself and can login now");

        }
    }

    private void OnClickCheckYourGames(ActionEvent e) {
        // TODO add your code here
        frame1.setVisible(false);
        myAvailableGames.setVisible(true);
    }

    private void OnClickCheckPlay(ActionEvent e) {
        // TODO add your code here
        frame1.setVisible(true);
        myAvailableGames.setVisible(false);
    }

    private void OnClickAccountPage(ActionEvent e) {
        // TODO add your code here
        this.setVisible(true);
        frame1.setVisible(false);
    }


    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents  @formatter:off
        // Generated using JFormDesigner Evaluation license - Ashhal
        myAvailableGames = new JFrame();
        label8 = new JLabel();
        label9 = new JLabel();
        scrollPane4 = new JScrollPane();
        myGamesList = new JList();
        button4 = new JButton();
        label15 = new JLabel();
        scrollPane5 = new JScrollPane();
        transactionList = new JList();
        loginPanel = new JPanel();
        button1 = new JButton();
        loginText = new JLabel();
        loginPasswordTextField = new JPasswordField();
        loginUsernameTextField = new JTextField();
        label13 = new JLabel();
        label14 = new JLabel();
        loginPanel2 = new JPanel();
        singUpText = new JLabel();
        signUpPasswordTextField = new JPasswordField();
        signUpUsernameTextField = new JTextField();
        signUpConfirmPasswordTextField2 = new JPasswordField();
        button2 = new JButton();
        label10 = new JLabel();
        label11 = new JLabel();
        label12 = new JLabel();
        frame1 = new JFrame();
        availableGamesPanel = new JPanel();
        label1 = new JLabel();
        label2 = new JLabel();
        label3 = new JLabel();
        scrollPane1 = new JScrollPane();
        normalGamesList = new JList();
        scrollPane2 = new JScrollPane();
        discounedGamesList = new JList();
        scrollPane3 = new JScrollPane();
        freeGamesList = new JList();
        label5 = new JLabel();
        label6 = new JLabel();
        label7 = new JLabel();
        purchaseButton = new JButton();
        label4 = new JLabel();
        button3 = new JButton();
        button5 = new JButton();

        //======== myAvailableGames ========
        {
            var myAvailableGamesContentPane = myAvailableGames.getContentPane();
            myAvailableGamesContentPane.setLayout(null);

            //---- label8 ----
            label8.setText("Your games library");
            label8.setHorizontalAlignment(SwingConstants.CENTER);
            label8.setFont(label8.getFont().deriveFont(label8.getFont().getStyle() | Font.BOLD, label8.getFont().getSize() + 15f));
            myAvailableGamesContentPane.add(label8);
            label8.setBounds(335, 50, 395, 60);

            //---- label9 ----
            label9.setText("Games");
            label9.setHorizontalAlignment(SwingConstants.CENTER);
            label9.setFont(label9.getFont().deriveFont(label9.getFont().getSize() + 9f));
            myAvailableGamesContentPane.add(label9);
            label9.setBounds(335, 145, 175, 45);

            //======== scrollPane4 ========
            {
                scrollPane4.setViewportView(myGamesList);
            }
            myAvailableGamesContentPane.add(scrollPane4);
            scrollPane4.setBounds(315, 190, 210, scrollPane4.getPreferredSize().height);

            //---- button4 ----
            button4.setText("Check Playstation games");
            button4.addActionListener(e -> OnClickCheckPlay(e));
            myAvailableGamesContentPane.add(button4);
            button4.setBounds(new Rectangle(new Point(40, 40), button4.getPreferredSize()));

            //---- label15 ----
            label15.setText("Transaction");
            label15.setHorizontalAlignment(SwingConstants.CENTER);
            label15.setFont(label15.getFont().deriveFont(label15.getFont().getSize() + 9f));
            myAvailableGamesContentPane.add(label15);
            label15.setBounds(590, 145, 175, 45);

            //======== scrollPane5 ========
            {
                scrollPane5.setViewportView(transactionList);
            }
            myAvailableGamesContentPane.add(scrollPane5);
            scrollPane5.setBounds(580, 190, 205, scrollPane5.getPreferredSize().height);

            {
                // compute preferred size
                Dimension preferredSize = new Dimension();
                for(int i = 0; i < myAvailableGamesContentPane.getComponentCount(); i++) {
                    Rectangle bounds = myAvailableGamesContentPane.getComponent(i).getBounds();
                    preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                    preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
                }
                Insets insets = myAvailableGamesContentPane.getInsets();
                preferredSize.width += insets.right;
                preferredSize.height += insets.bottom;
                myAvailableGamesContentPane.setMinimumSize(preferredSize);
                myAvailableGamesContentPane.setPreferredSize(preferredSize);
            }
            myAvailableGames.pack();
            myAvailableGames.setLocationRelativeTo(myAvailableGames.getOwner());
        }

        //======== this ========
        setBorder (new javax. swing. border. CompoundBorder( new javax .swing .border .TitledBorder (new javax
        . swing. border. EmptyBorder( 0, 0, 0, 0) , "JF\u006frmDesi\u0067ner Ev\u0061luatio\u006e", javax. swing
        . border. TitledBorder. CENTER, javax. swing. border. TitledBorder. BOTTOM, new java .awt .
        Font ("Dialo\u0067" ,java .awt .Font .BOLD ,12 ), java. awt. Color. red
        ) , getBorder( )) );  addPropertyChangeListener (new java. beans. PropertyChangeListener( ){ @Override
        public void propertyChange (java .beans .PropertyChangeEvent e) {if ("borde\u0072" .equals (e .getPropertyName (
        ) )) throw new RuntimeException( ); }} );
        setLayout(null);

        //======== loginPanel ========
        {
            loginPanel.setLayout(null);

            //---- button1 ----
            button1.setText("Login");
            button1.addActionListener(e -> {
			button1(e);
			OnClickLogin(e);
		});
            loginPanel.add(button1);
            button1.setBounds(230, 215, 100, 30);

            //---- loginText ----
            loginText.setText("Login");
            loginText.setHorizontalAlignment(SwingConstants.CENTER);
            loginText.setFont(loginText.getFont().deriveFont(loginText.getFont().getSize() + 8f));
            loginPanel.add(loginText);
            loginText.setBounds(230, 0, 100, 40);
            loginPanel.add(loginPasswordTextField);
            loginPasswordTextField.setBounds(180, 140, 190, 42);
            loginPanel.add(loginUsernameTextField);
            loginUsernameTextField.setBounds(185, 95, 180, loginUsernameTextField.getPreferredSize().height);

            //---- label13 ----
            label13.setText("Username");
            loginPanel.add(label13);
            label13.setBounds(95, 105, 75, 20);

            //---- label14 ----
            label14.setText("Password");
            loginPanel.add(label14);
            label14.setBounds(95, 150, 75, 20);
        }
        add(loginPanel);
        loginPanel.setBounds(100, 65, 380, 325);

        //======== loginPanel2 ========
        {
            loginPanel2.setLayout(null);

            //---- singUpText ----
            singUpText.setText("Signup");
            singUpText.setHorizontalAlignment(SwingConstants.CENTER);
            singUpText.setFont(singUpText.getFont().deriveFont(singUpText.getFont().getSize() + 8f));
            loginPanel2.add(singUpText);
            singUpText.setBounds(265, 0, 100, 40);
            loginPanel2.add(signUpPasswordTextField);
            signUpPasswordTextField.setBounds(215, 115, 190, 42);
            loginPanel2.add(signUpUsernameTextField);
            signUpUsernameTextField.setBounds(220, 65, 180, signUpUsernameTextField.getPreferredSize().height);
            loginPanel2.add(signUpConfirmPasswordTextField2);
            signUpConfirmPasswordTextField2.setBounds(215, 170, 190, 42);

            //---- button2 ----
            button2.setText("Signup");
            button2.addActionListener(e -> OnClickSignup(e));
            loginPanel2.add(button2);
            button2.setBounds(265, 245, 110, button2.getPreferredSize().height);

            //---- label10 ----
            label10.setText("Username");
            loginPanel2.add(label10);
            label10.setBounds(125, 70, 65, 20);

            //---- label11 ----
            label11.setText("Set Password");
            loginPanel2.add(label11);
            label11.setBounds(115, 125, 85, 20);

            //---- label12 ----
            label12.setText("Confirm Password");
            loginPanel2.add(label12);
            label12.setBounds(95, 185, 115, 20);
        }
        add(loginPanel2);
        loginPanel2.setBounds(485, 60, 465, 325);

        {
            // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < getComponentCount(); i++) {
                Rectangle bounds = getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            setMinimumSize(preferredSize);
            setPreferredSize(preferredSize);
        }

        //======== frame1 ========
        {
            var frame1ContentPane = frame1.getContentPane();
            frame1ContentPane.setLayout(null);

            //======== availableGamesPanel ========
            {
                availableGamesPanel.setBorder (new javax. swing. border. CompoundBorder( new javax .swing .border .TitledBorder (new javax. swing. border. EmptyBorder(
                0, 0, 0, 0) , "JFor\u006dDesi\u0067ner \u0045valu\u0061tion", javax. swing. border. TitledBorder. CENTER, javax. swing. border. TitledBorder
                . BOTTOM, new java .awt .Font ("Dia\u006cog" ,java .awt .Font .BOLD ,12 ), java. awt. Color.
                red) ,availableGamesPanel. getBorder( )) ); availableGamesPanel. addPropertyChangeListener (new java. beans. PropertyChangeListener( ){ @Override public void propertyChange (java .
                beans .PropertyChangeEvent e) {if ("bord\u0065r" .equals (e .getPropertyName () )) throw new RuntimeException( ); }} );
                availableGamesPanel.setLayout(null);

                //---- label1 ----
                label1.setText("Normal Games");
                label1.setFont(label1.getFont().deriveFont(label1.getFont().getSize() + 7f));
                availableGamesPanel.add(label1);
                label1.setBounds(150, 90, 125, 40);

                //---- label2 ----
                label2.setText("Discounted Games");
                label2.setFont(label2.getFont().deriveFont(label2.getFont().getSize() + 7f));
                availableGamesPanel.add(label2);
                label2.setBounds(375, 85, 170, 40);

                //---- label3 ----
                label3.setText("Free Games");
                label3.setFont(label3.getFont().deriveFont(label3.getFont().getSize() + 7f));
                availableGamesPanel.add(label3);
                label3.setBounds(660, 85, 100, 40);

                //======== scrollPane1 ========
                {

                    //---- normalGamesList ----
                    normalGamesList.setLayoutOrientation(JList.HORIZONTAL_WRAP);
                    normalGamesList.addListSelectionListener(e -> normalGamesListValueChanged(e));
                    scrollPane1.setViewportView(normalGamesList);
                }
                availableGamesPanel.add(scrollPane1);
                scrollPane1.setBounds(75, 145, 255, 195);

                //======== scrollPane2 ========
                {

                    //---- discounedGamesList ----
                    discounedGamesList.setLayoutOrientation(JList.HORIZONTAL_WRAP);
                    discounedGamesList.addListSelectionListener(e -> discounedGamesListValueChanged(e));
                    scrollPane2.setViewportView(discounedGamesList);
                }
                availableGamesPanel.add(scrollPane2);
                scrollPane2.setBounds(355, 145, 210, 195);

                //======== scrollPane3 ========
                {

                    //---- freeGamesList ----
                    freeGamesList.setLayoutOrientation(JList.HORIZONTAL_WRAP);
                    freeGamesList.addListSelectionListener(e -> freeGamesListValueChanged(e));
                    scrollPane3.setViewportView(freeGamesList);
                }
                availableGamesPanel.add(scrollPane3);
                scrollPane3.setBounds(600, 145, 230, 195);

                //---- label5 ----
                label5.setText("500$");
                label5.setHorizontalAlignment(SwingConstants.CENTER);
                label5.setFont(label5.getFont().deriveFont(label5.getFont().getStyle() | Font.BOLD, label5.getFont().getSize() + 6f));
                availableGamesPanel.add(label5);
                label5.setBounds(150, 345, 90, 40);

                //---- label6 ----
                label6.setText("300$");
                label6.setHorizontalAlignment(SwingConstants.CENTER);
                label6.setFont(label6.getFont().deriveFont(label6.getFont().getStyle() | Font.BOLD, label6.getFont().getSize() + 6f));
                availableGamesPanel.add(label6);
                label6.setBounds(410, 350, 90, 40);

                //---- label7 ----
                label7.setText("0$");
                label7.setHorizontalAlignment(SwingConstants.CENTER);
                label7.setFont(label7.getFont().deriveFont(label7.getFont().getStyle() | Font.BOLD, label7.getFont().getSize() + 6f));
                availableGamesPanel.add(label7);
                label7.setBounds(670, 350, 90, 40);

                //---- purchaseButton ----
                purchaseButton.setText("Purchase");
                purchaseButton.addActionListener(e -> OnClickPurchase(e));
                availableGamesPanel.add(purchaseButton);
                purchaseButton.setBounds(new Rectangle(new Point(405, 425), purchaseButton.getPreferredSize()));

                {
                    // compute preferred size
                    Dimension preferredSize = new Dimension();
                    for(int i = 0; i < availableGamesPanel.getComponentCount(); i++) {
                        Rectangle bounds = availableGamesPanel.getComponent(i).getBounds();
                        preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                        preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
                    }
                    Insets insets = availableGamesPanel.getInsets();
                    preferredSize.width += insets.right;
                    preferredSize.height += insets.bottom;
                    availableGamesPanel.setMinimumSize(preferredSize);
                    availableGamesPanel.setPreferredSize(preferredSize);
                }
            }
            frame1ContentPane.add(availableGamesPanel);
            availableGamesPanel.setBounds(65, 70, 935, 485);

            //---- label4 ----
            label4.setText("Games Available For PlayStation");
            label4.setFont(label4.getFont().deriveFont(label4.getFont().getStyle() | Font.BOLD, label4.getFont().getSize() + 10f));
            label4.setHorizontalAlignment(SwingConstants.CENTER);
            frame1ContentPane.add(label4);
            label4.setBounds(380, 30, 355, 40);

            //---- button3 ----
            button3.setText("Check your games");
            button3.addActionListener(e -> OnClickCheckYourGames(e));
            frame1ContentPane.add(button3);
            button3.setBounds(new Rectangle(new Point(35, 35), button3.getPreferredSize()));

            //---- button5 ----
            button5.setText("Back to acount page");
            button5.addActionListener(e -> OnClickAccountPage(e));
            frame1ContentPane.add(button5);
            button5.setBounds(845, 40, 175, 30);

            {
                // compute preferred size
                Dimension preferredSize = new Dimension();
                for(int i = 0; i < frame1ContentPane.getComponentCount(); i++) {
                    Rectangle bounds = frame1ContentPane.getComponent(i).getBounds();
                    preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                    preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
                }
                Insets insets = frame1ContentPane.getInsets();
                preferredSize.width += insets.right;
                preferredSize.height += insets.bottom;
                frame1ContentPane.setMinimumSize(preferredSize);
                frame1ContentPane.setPreferredSize(preferredSize);
            }
            frame1.pack();
            frame1.setLocationRelativeTo(frame1.getOwner());
        }
        // JFormDesigner - End of component initialization  //GEN-END:initComponents  @formatter:on
    }

    public static void main(String[] args) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/playerprofilenetwork", "root", "nightcore123");
            DatabaseImplementation db = new DatabaseImplementation(connection);
            System.out.println("Connection is been established");
            JFrame frame = new JFrame("My new GUI Designer form");
            frame.setContentPane(new GUIDesigner(db, connection));
            frame.pack();
            frame.setVisible(true);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables  @formatter:off
    // Generated using JFormDesigner Evaluation license - Ashhal
    private JFrame myAvailableGames;
    private JLabel label8;
    private JLabel label9;
    private JScrollPane scrollPane4;
    private JList myGamesList;
    private JButton button4;
    private JLabel label15;
    private JScrollPane scrollPane5;
    private JList transactionList;
    private JPanel loginPanel;
    private JButton button1;
    private JLabel loginText;
    private JPasswordField loginPasswordTextField;
    private JTextField loginUsernameTextField;
    private JLabel label13;
    private JLabel label14;
    private JPanel loginPanel2;
    private JLabel singUpText;
    private JPasswordField signUpPasswordTextField;
    private JTextField signUpUsernameTextField;
    private JPasswordField signUpConfirmPasswordTextField2;
    private JButton button2;
    private JLabel label10;
    private JLabel label11;
    private JLabel label12;
    private JFrame frame1;
    private JPanel availableGamesPanel;
    private JLabel label1;
    private JLabel label2;
    private JLabel label3;
    private JScrollPane scrollPane1;
    private JList normalGamesList;
    private JScrollPane scrollPane2;
    private JList discounedGamesList;
    private JScrollPane scrollPane3;
    private JList freeGamesList;
    private JLabel label5;
    private JLabel label6;
    private JLabel label7;
    private JButton purchaseButton;
    private JLabel label4;
    private JButton button3;
    private JButton button5;
    // JFormDesigner - End of variables declaration  //GEN-END:variables  @formatter:on
}
